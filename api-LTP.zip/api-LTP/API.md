## Tabela de Endpoints

| Verbo HTTP | Descrição Path da Funcionalidade | Path (Exemplo) | Dados de envio em JSON (Body) | Dados de Resposta em JSON (Body) |
| :--- | :--- | :--- | :--- | :--- |
| **GET** | `/api/usuarios` <br> Recupera a lista de todos os usuários. | `GET /api/usuarios` | | `[{"id": 1, "nome": "Adoentado 1", "email": "adoentado1@email.com", "telefone": "11999998888"}]` |
| **GET** | `/api/usuarios/{id}` <br> Recupera um usuário específico pelo ID. | `GET /api/usuarios/1` | | `{"id": 1, "nome": "Adoentado 1", "email": "adoentado1@email.com", "telefone": "11999998888"}` |
| **POST** | `/api/usuarios` <br> Cadastra um novo usuário. | `POST /api/usuarios` | `{"id": 3, "nome": "Novo Usuario", "email": "novo@email.com", "telefone": "11888887777"}` | `{"id": 3, "nome": "Novo Usuario", "email": "novo@email.com", "telefone": "11888887777"}` |
| **PUT** | `/api/usuarios/{id}` <br> Atualiza dados de um usuário existente. | `PUT /api/usuarios/1` | `{"nome": "Adoentado Alterado", "email": "adoentado1@email.com"}` | `{"id": 1, "nome": "Adoentado Alterado", "email": "adoentado1@email.com", "telefone": "11999998888"}` |
| **DELETE** | `/api/usuarios/{id}` <br> Remove um usuário específico pelo ID. | `DELETE /api/usuarios/1` | | `{"id": 1, "nome": "Adoentado Alterado", "email": "adoentado1@email.com", "telefone": "11999998888"}` <br> *Retorna o objeto removido* |
| **GET** | `/api/itens` <br> Recupera a lista de todos os itens cadastrados. | `GET /api/itens` | | `[{"id": 101, "nome": "Desconto Roupas", "preco": 49.99, "categoria": "Roupas"}]` |
| **GET** | `/api/itens/{id}` <br> Recupera um item específico pelo ID. | `GET /api/itens/101` | | `{"id": 101, "nome": "Desconto Roupas", "preco": 49.99, "categoria": "Roupas"}` |
| **POST** | `/api/itens` <br> Cadastra um novo item. | `POST /api/itens` | `{"id": 103, "nome": "Novo Item", "preco": 99.90, "categoria": "Variados"}` | `{"id": 103, "nome": "Novo Item", "preco": 99.90, "categoria": "Variados"}` |
| **PUT** | `/api/itens/{id}` <br> Atualiza dados de um item existente. | `PUT /api/itens/101` | `{"nome": "Desconto Roupas Especial", "preco": 39.99}` | `{"id": 101, "nome": "Desconto Roupas Especial", "preco": 39.99, "categoria": "Roupas"}` |
| **DELETE** | `/api/itens/{id}` <br> Remove um item específico pelo ID. | `DELETE /api/itens/101` | | `{"id": 101, "nome": "Desconto Roupas Especial", "preco": 39.99, "categoria": "Roupas"}` <br> *Retorna o objeto removido* |
