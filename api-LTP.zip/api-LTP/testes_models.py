from models.usuario import Usuario
from models.item import Item

def testar_usuario():
    print("--- Testando Classe Usuario ---")
    try:
        user1 = Usuario(1, "João Silva", "joao@email.com", "11999999999")
        print("Criado com sucesso:", user1)
    except Exception as e:
        print("Erro inesperado:", e)
    try:
        user2 = Usuario(-1, "Maria", "maria@email.com", "1188888888")
    except ValueError as e:
        print("Erro esperado capturado (ID inválido):", e)
    try:
        user3 = Usuario(2, "Maria", "emailsemarroba", "1188888888")
    except ValueError as e:
        print("Erro esperado capturado (Email inválido):", e)

def testar_item():
    print("\n--- Testando Classe Item ---")
    
    try:
        item1 = Item(101, "Camisa Branca", 49.90, "Roupas")
        print("Criado com sucesso:", item1)
    except Exception as e:
        print("Erro inesperado:", e)
    try:
        item2 = Item(102, "Calça Jeans", -20.0, "Roupas")
    except ValueError as e:
        print("Erro esperado capturado (Preço inválido):", e)
    try:
        item3 = Item(103, "   ", 15.0, "Acessórios")
    except ValueError as e:
        print("Erro esperado capturado (Nome inválido):", e)

if __name__ == "__main__":
    testar_usuario()
    testar_item()
