from flask import Flask, jsonify
from routes.usuario_routes import usuario_bp
from routes.item_routes import item_bp

app = Flask(__name__)

app.register_blueprint(usuario_bp)
app.register_blueprint(item_bp)

@app.route("/", methods=["GET"])
def home():
    return jsonify({
        "mensagem": "Bem-vindo à API LTP Simplificada!",
        "endpoints": {
            "usuarios": "/api/usuarios",
            "itens": "/api/itens"
        }
    }), 200

if __name__ == "__main__":
    app.run(debug=True, port=5000)
