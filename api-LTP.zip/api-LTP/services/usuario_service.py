from models.usuario import Usuario

usuarios_db = [
    Usuario(1, "joaopedro", "joao@email.com", "11999998888"),
    Usuario(2, "milena", "milena@email.com", "11999997777")
]

class UsuarioService:
    def get_all(self):
        result = []
        for u in usuarios_db:
            result.append(u.to_dict())
        return result

    def get_by_id(self, id_usuario):
        for u in usuarios_db:
            if u.get_id() == id_usuario:
                return u.to_dict()
        return None

    def create(self, data):
        if "id" not in data or "nome" not in data or "email" not in data or "telefone" not in data:
            raise ValueError("Campos obrigatórios ausentes.")
        
        for u in usuarios_db:
            if u.get_id() == data["id"]:
                raise ValueError("Usuário com este ID já existe.")

        novo_usuario = Usuario(
            id_usuario=data["id"],
            nome=data["nome"],
            email=data["email"],
            telefone=data["telefone"]
        )
        usuarios_db.append(novo_usuario)
        return novo_usuario.to_dict()

    def update(self, id_usuario, data):
        usuario_encontrado = None
        for u in usuarios_db:
            if u.get_id() == id_usuario:
                usuario_encontrado = u
                break
        
        if not usuario_encontrado:
            return None
        
        if "nome" in data:
            usuario_encontrado.set_nome(data["nome"])
        if "email" in data:
            usuario_encontrado.set_email(data["email"])
        if "telefone" in data:
            usuario_encontrado.set_telefone(data["telefone"])
            
        return usuario_encontrado.to_dict()

    def delete(self, id_usuario):
        for idx, u in enumerate(usuarios_db):
            if u.get_id() == id_usuario:
                removido = usuarios_db.pop(idx)
                return removido.to_dict()
        return None
