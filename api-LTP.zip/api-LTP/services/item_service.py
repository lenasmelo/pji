from models.item import Item

itens_db = [
    Item(101, "Desconto Roupas", 49.99, "Roupas"),
    Item(102, "Desconto Eletrônicos", 1999.99, "Eletrônicos")
]

class ItemService:
    def get_all(self):
        result = []
        for i in itens_db:
            result.append(i.to_dict())
        return result

    def get_by_id(self, id_item):
        for i in itens_db:
            if i.get_id() == id_item:
                return i.to_dict()
        return None

    def create(self, data):
        if "id" not in data or "nome" not in data or "preco" not in data or "categoria" not in data:
            raise ValueError("Campos obrigatórios ausentes.")
        
        for i in itens_db:
            if i.get_id() == data["id"]:
                raise ValueError("Item com este ID já existe.")

        novo_item = Item(
            id_item=data["id"],
            nome=data["nome"],
            preco=data["preco"],
            categoria=data["categoria"]
        )
        itens_db.append(novo_item)
        return novo_item.to_dict()

    def update(self, id_item, data):
        item_encontrado = None
        for i in itens_db:
            if i.get_id() == id_item:
                item_encontrado = i
                break
        
        if not item_encontrado:
            return None
        
        if "nome" in data:
            item_encontrado.set_nome(data["nome"])
        if "preco" in data:
            item_encontrado.set_preco(data["preco"])
        if "categoria" in data:
            item_encontrado.set_categoria(data["categoria"])
            
        return item_encontrado.to_dict()

    def delete(self, id_item):
        for idx, i in enumerate(itens_db):
            if i.get_id() == id_item:
                removido = itens_db.pop(idx)
                return removido.to_dict()
        return None
