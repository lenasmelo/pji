import json
from app import app

def rodar_testes():
    client = app.test_client()

    # lista completa de todos os usuarios
    res = client.get("/api/usuarios")
    print("GET /api/usuarios:", res.status_code)
    print(res.get_json())

    # um usuario específico (ID 1) existente no sistema
    res = client.get("/api/usuarios/1")
    print("GET /api/usuarios/1 (Existente):", res.status_code)
    print(res.get_json())

    # um usuario com ID inexistente (ID 999) para validar o erro 404
    res = client.get("/api/usuarios/999")
    print("GET /api/usuarios/999 (Inexistente):", res.status_code)
    print(res.get_json())

    # cadastra um novo usuario com dados validos
    novo_usuario = {
        "id": 3,
        "nome": "Carla Silva",
        "email": "carla@email.com",
        "telefone": "11999995555"
    }
    res = client.post("/api/usuarios", json=novo_usuario)
    print("POST /api/usuarios (Sucesso):", res.status_code)
    print(res.get_json())

    # cadastra um usuario com dados invalidos para rejeição e o erro 400
    usuario_invalido = {
        "id": 4,
        "nome": "",
        "email": "invalido",
        "telefone": "123"
    }
    res = client.post("/api/usuarios", json=usuario_invalido)
    print("POST /api/usuarios (Dados Invalidos):", res.status_code)
    print(res.get_json())

    # atualiza as informacoes de um usuario existente (ID 3)
    dados_atualizados = {
        "nome": "Carla Souza",
        "email": "carlasouza@email.com"
    }
    res = client.put("/api/usuarios/3", json=dados_atualizados)
    print("PUT /api/usuarios/3 (Sucesso):", res.status_code)
    print(res.get_json())

    # exclui o usuario cadastrado (ID 3) do banco de dados em memoria
    res = client.delete("/api/usuarios/3")
    print("DELETE /api/usuarios/3 (Sucesso):", res.status_code)
    print(res.get_json())

    # lista novamente os usuarios para comprovar que o usuario ID 3 foi removido com sucesso
    res = client.get("/api/usuarios")
    print("GET /api/usuarios (Apos remocao):", res.status_code)
    print(res.get_json())

    # lista completa de todos os itens em promocao
    res = client.get("/api/itens")
    print("GET /api/itens:", res.status_code)
    print(res.get_json())

    # um item especifico (ID 101) existente no sistema
    res = client.get("/api/itens/101")
    print("GET /api/itens/101 (Existente):", res.status_code)
    print(res.get_json())

    # item com ID inexistente (ID 999) para validar o erro 404
    res = client.get("/api/itens/999")
    print("GET /api/itens/999 (Inexistente):", res.status_code)
    print(res.get_json())

    # Cadastra um novo item com dados válidos
    novo_item = {
        "id": 103,
        "nome": "Desconto Calcados - Tenis Casual",
        "preco": 89.90,
        "categoria": "Calcados"
    }
    res = client.post("/api/itens", json=novo_item)
    print("POST /api/itens (Sucesso):", res.status_code)
    print(res.get_json())

    # tenta cadastrar um item com preço negativo par o erro 400
    item_invalido = {
        "id": 104,
        "nome": "Tenis Invalido",
        "preco": -5.0,
        "categoria": "Calcados"
    }
    res = client.post("/api/itens", json=item_invalido)
    print("POST /api/itens (Dados Invalidos):", res.status_code)
    print(res.get_json())

    # atualiza as informacoes de um item existente (ID 103)
    item_atualizado = {
        "nome": "Tenis Casual Confortavel",
        "preco": 99.90
    }
    res = client.put("/api/itens/103", json=item_atualizado)
    print("PUT /api/itens/103 (Sucesso):", res.status_code)
    print(res.get_json())

    # exclui o item cadastrado (ID 103) do banco de dados em memória
    res = client.delete("/api/itens/103")
    print("DELETE /api/itens/103 (Sucesso):", res.status_code)
    print(res.get_json())

    # lista novamente os itens para comprovar que o item ID 103 foi removido com sucesso
    res = client.get("/api/itens")
    print("GET /api/itens (Apos remocao):", res.status_code)
    print(res.get_json())

if __name__ == "__main__":
    rodar_testes()
