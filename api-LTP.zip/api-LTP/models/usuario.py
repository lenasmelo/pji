class Usuario:
    def __init__(self, id_usuario, nome, email, telefone):
        self._id = None
        self._nome = None
        self._email = None
        self._telefone = None
        
        self.set_id(id_usuario)
        self.set_nome(nome)
        self.set_email(email)
        self.set_telefone(telefone)

    def get_id(self):
        return self._id

    def set_id(self, id_usuario):
        if type(id_usuario) is not int or id_usuario <= 0:
            raise ValueError("ID deve ser um número inteiro positivo.")
        self._id = id_usuario

    def get_nome(self):
        return self._nome

    def set_nome(self, nome):
        if not nome or type(nome) is not str or len(nome.strip()) == 0:
            raise ValueError("Nome inválido.")
        self._nome = nome.strip()

    def get_email(self):
        return self._email

    def set_email(self, email):
        if not email or type(email) is not str or "@" not in email:
            raise ValueError("Email inválido.")
        self._email = email.strip()

    def get_telefone(self):
        return self._telefone

    def set_telefone(self, telefone):
        if not telefone or type(telefone) is not str or len(telefone.strip()) < 8:
            raise ValueError("Telefone inválido.")
        self._telefone = telefone.strip()

    def to_dict(self):
        return {
            "id": self.get_id(),
            "nome": self.get_nome(),
            "email": self.get_email(),
            "telefone": self.get_telefone()
        }

    def __str__(self):
        return f"Usuario(ID: {self._id}, Nome: '{self._nome}', Email: '{self._email}', Telefone: '{self._telefone}')"
