class Item:
    def __init__(self, id_item, nome, preco, categoria):
        self._id = None
        self._nome = None
        self._preco = None
        self._categoria = None
        
        self.set_id(id_item)
        self.set_nome(nome)
        self.set_preco(preco)
        self.set_categoria(categoria)

    def get_id(self):
        return self._id

    def set_id(self, id_item):
        if type(id_item) is not int or id_item <= 0:
            raise ValueError("ID deve ser um número inteiro positivo.")
        self._id = id_item

    def get_nome(self):
        return self._nome

    def set_nome(self, nome):
        if not nome or type(nome) is not str or len(nome.strip()) == 0:
            raise ValueError("Nome inválido.")
        self._nome = nome.strip()

    def get_preco(self):
        return self._preco

    def set_preco(self, preco):
        if type(preco) not in (int, float) or preco < 0:
            raise ValueError("Preço deve ser um número positivo.")
        self._preco = float(preco)

    def get_categoria(self):
        return self._categoria

    def set_categoria(self, categoria):
        if not categoria or type(categoria) is not str or len(categoria.strip()) == 0:
            raise ValueError("Categoria inválida.")
        self._categoria = categoria.strip()

    def to_dict(self):
        return {
            "id": self.get_id(),
            "nome": self.get_nome(),
            "preco": self.get_preco(),
            "categoria": self.get_categoria()
        }

    def __str__(self):
        return f"Item(ID: {self._id}, Nome: '{self._nome}', Preço: R${self._preco:.2f}, Categoria: '{self._categoria}')"
