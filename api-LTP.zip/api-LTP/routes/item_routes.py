from flask import Blueprint, request, jsonify
from services.item_service import ItemService

item_bp = Blueprint("item", __name__)
item_service = ItemService()

@item_bp.route("/api/itens", methods=["GET"])
def get_itens():
    itens = item_service.get_all()
    return jsonify(itens), 200

@item_bp.route("/api/itens/<int:id_item>", methods=["GET"])
def get_item(id_item):
    item = item_service.get_by_id(id_item)
    if item is None:
        return jsonify({"erro": "Item não encontrado."}), 404
    return jsonify(item), 200

@item_bp.route("/api/itens", methods=["POST"])
def post_item():
    dados = request.get_json()
    if not dados:
        return jsonify({"erro": "Dados inválidos ou ausentes."}), 400
    try:
        novo = item_service.create(dados)
        return jsonify(novo), 201
    except ValueError as e:
        return jsonify({"erro": str(e)}), 400

@item_bp.route("/api/itens/<int:id_item>", methods=["PUT"])
def put_item(id_item):
    dados = request.get_json()
    if not dados:
        return jsonify({"erro": "Dados inválidos ou ausentes."}), 400
    try:
        atualizado = item_service.update(id_item, dados)
        if atualizado is None:
            return jsonify({"erro": "Item não encontrado."}), 404
        return jsonify(atualizado), 200
    except ValueError as e:
        return jsonify({"erro": str(e)}), 400

@item_bp.route("/api/itens/<int:id_item>", methods=["DELETE"])
def delete_item(id_item):
    removido = item_service.delete(id_item)
    if removido is None:
        return jsonify({"erro": "Item não encontrado."}), 404
    return jsonify(removido), 200
