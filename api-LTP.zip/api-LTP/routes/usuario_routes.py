from flask import Blueprint, request, jsonify
from services.usuario_service import UsuarioService

usuario_bp = Blueprint("usuario", __name__)
usuario_service = UsuarioService()

@usuario_bp.route("/api/usuarios", methods=["GET"])
def get_usuarios():
    usuarios = usuario_service.get_all()
    return jsonify(usuarios), 200

@usuario_bp.route("/api/usuarios/<int:id_usuario>", methods=["GET"])
def get_usuario(id_usuario):
    usuario = usuario_service.get_by_id(id_usuario)
    if usuario is None:
        return jsonify({"erro": "Usuário não encontrado."}), 404
    return jsonify(usuario), 200

@usuario_bp.route("/api/usuarios", methods=["POST"])
def post_usuario():
    dados = request.get_json()
    if not dados:
        return jsonify({"erro": "Dados inválidos ou ausentes."}), 400
    try:
        novo = usuario_service.create(dados)
        return jsonify(novo), 201
    except ValueError as e:
        return jsonify({"erro": str(e)}), 400

@usuario_bp.route("/api/usuarios/<int:id_usuario>", methods=["PUT"])
def put_usuario(id_usuario):
    dados = request.get_json()
    if not dados:
        return jsonify({"erro": "Dados inválidos ou ausentes."}), 400
    try:
        atualizado = usuario_service.update(id_usuario, dados)
        if atualizado is None:
            return jsonify({"erro": "Usuário não encontrado."}), 404
        return jsonify(atualizado), 200
    except ValueError as e:
        return jsonify({"erro": str(e)}), 400

@usuario_bp.route("/api/usuarios/<int:id_usuario>", methods=["DELETE"])
def delete_usuario(id_usuario):
    removido = usuario_service.delete(id_usuario)
    if removido is None:
        return jsonify({"erro": "Usuário não encontrado."}), 404
    return jsonify(removido), 200
